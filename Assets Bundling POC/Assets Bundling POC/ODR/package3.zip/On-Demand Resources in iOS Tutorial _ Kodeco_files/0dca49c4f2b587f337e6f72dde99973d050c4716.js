let anchors=document.querySelectorAll("a.button"),hrefs=Array.from(anchors).map((e=>e.href))
window.parent.postMessage({topicLinks:hrefs},"https://www.kodeco.com")

//# sourceMappingURL=0dca49c4f2b587f337e6f72dde99973d050c4716.map?__ws=forums.kodeco.com

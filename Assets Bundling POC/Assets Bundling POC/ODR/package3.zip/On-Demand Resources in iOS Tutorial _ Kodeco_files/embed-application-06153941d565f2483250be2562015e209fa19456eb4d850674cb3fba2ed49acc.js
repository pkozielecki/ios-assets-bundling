(function(){const e=document.getElementById("data-embedded").dataset.referer
function t(t){parent&&parent.postMessage(t,e)}function n(e){let n=e.target.getAttribute("data-link-to-post")
if(n){let o=document.getElementById("post-"+n)
if(o){let n=o.getBoundingClientRect()
if(n&&n.top)return t({type:"discourse-scroll",top:n.top}),e.preventDefault(),!1}}}window.onload=function(){let e=document.querySelector("[data-embed-state]"),o="unknown",l=null
e&&(o=e.getAttribute("data-embed-state"),l=e.getAttribute("data-embed-id")),t({type:"discourse-resize",height:document.body.offsetHeight,state:o,embedId:l})
let r,d=document.querySelectorAll("a[data-link-to-post]")
for(r=0;r<d.length;r++)d[r].onclick=n
let a=document.querySelectorAll(".cooked a")
for(r=0;r<a.length;r++)a[r].target="_blank"
let u=document.querySelectorAll(".username a")
for(r=0;r<u.length;r++){let e=u[r].innerHTML
e&&(u[r].innerHTML=new BreakString(e).break())}}})()

//# sourceMappingURL=embed-application-d7052786de1fb05c5a1ffe8bd75c19ad5df3a04d4cfba2b048abb8b95eedd3c4.map
//!
;
